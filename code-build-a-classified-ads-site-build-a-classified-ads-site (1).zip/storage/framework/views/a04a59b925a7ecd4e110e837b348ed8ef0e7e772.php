<div class="form-group<?php echo e($errors->has('category_id') ? ' has-error' : ''); ?>">
    <label for="category" class="control-label">Category</label>
    <select name="category_id" id="category" class="form-control"<?php echo e(isset($listing) && $listing->live() ? ' disabled="disabled"' : ''); ?>>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <optgroup label="<?php echo e($category->name); ?>">
                <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($listing) && $listing->category_id == $child->id || old('category_id') == $child->id): ?>
                        <option value="<?php echo e($child->id); ?>" selected="selected"><?php echo e($child->name); ?> (£<?php echo e(number_format($child->price, 2)); ?>)</option>
                    <?php else: ?>
                        <option value="<?php echo e($child->id); ?>"><?php echo e($child->name); ?> (£<?php echo e(number_format($child->price, 2)); ?>)</option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </optgroup>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php if($errors->has('category_id')): ?>
        <span class="help-block">
            <?php echo e($errors->first('category_id')); ?>

        </span>
    <?php endif; ?>
</div>
