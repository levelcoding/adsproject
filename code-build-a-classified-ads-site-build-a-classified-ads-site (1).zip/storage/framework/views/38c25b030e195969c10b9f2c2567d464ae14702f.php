<div class="media">
    <div class="media-body">
        <h5>
            <strong><a href="<?php echo e(route('listings.show', [$area, $listing])); ?>"><?php echo e($listing->title); ?></a></strong>
            <?php if($area->children->count()): ?>
                in <?php echo e($listing->area->name); ?>

            <?php endif; ?>
        </h5>

        <ul class="list-inline">
            <li><time><?php echo e($listing->created_at->diffForHumans()); ?></time></li>
            <li><?php echo e($listing->user->name); ?></li>
        </ul>

        <?php echo e(isset($links) ? $links : ''); ?>

    </div>
</div>
