<?php $__env->startSection('content'); ?>
    <p>Showing your last <?php echo e($indexLimit); ?> viewed listings.</p>
    <?php if($listings->count()): ?>
        <?php echo $__env->renderEach('listings.partials._listing', $listings, 'listing'); ?>
    <?php else: ?>
        <p>You have no viewed listings.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>