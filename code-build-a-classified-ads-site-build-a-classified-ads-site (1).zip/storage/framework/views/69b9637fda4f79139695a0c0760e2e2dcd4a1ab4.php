<?php $__env->startComponent('listings.partials._base_listing', compact('listing')); ?>
    <?php $__env->slot('links'); ?>
        <ul class="list-inline">
            <li>Added <?php echo e($listing->pivot->created_at->diffForHumans()); ?></li>
            <li><a href=""></a></li>
        </ul>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>