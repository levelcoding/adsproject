<?php if(isset($category)): ?>
    <listing-search category-id="<?php echo e($category->id); ?>" :area-ids="<?php echo e($area->descendants->pluck('id')->push($area->id)); ?>"></listing-search>
<?php else: ?>
    <listing-search :area-ids="<?php echo e($area->descendants->pluck('id')->push($area->id)); ?>"></listing-search>
<?php endif; ?>

<hr>