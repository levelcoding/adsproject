<?php $__env->startComponent('listings.partials._base_listing', compact('listing')); ?>
    <?php $__env->slot('links'); ?>
        <ul class="list-inline">
            <li>Added <?php echo e($listing->pivot->created_at->diffForHumans()); ?></li>
            <li><a href="#" onclick="event.preventDefault(); document.getElementById('listings-favourites-destroy-<?php echo e($listing->id); ?>').submit();">Delete</a></li>
        </ul>

        <form action="<?php echo e(route('listings.favourites.destroy', [$area, $listing])); ?>" method="post" id="listings-favourites-destroy-<?php echo e($listing->id); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

        </form>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
