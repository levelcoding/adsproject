Hi <?php echo e($listing->user->name); ?>,<br><br>

<?php echo e($sender->name); ?> has contacted you about your listing, <a href="<?php echo e(route('listings.show', [$listing->area, $listing])); ?>"><?php echo e($listing->title); ?></a>.<br><br>

---<br>
<?php echo nl2br(e($body)); ?><br>
---<br><br>

Reply directly to this email to get back to them.
