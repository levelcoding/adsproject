<div class="media">
    <div class="media-body">
        <h5>
            <strong>
                <?php if($listing->live()): ?>
                    <a href="<?php echo e(route('listings.show', [$area, $listing])); ?>"><?php echo e($listing->title); ?></a>
                <?php else: ?>
                    <?php echo e($listing->title); ?>

                <?php endif; ?>
            </strong>

            in <?php echo e($listing->area->name); ?>

        </h5>

        <ul class="list-inline">
            <li><time><?php echo e($listing->created_at->diffForHumans()); ?></time></li>
            <li>Last updated <time><?php echo e($listing->updated_at->diffForHumans()); ?></time></li>
        </ul>

        <ul class="list-inline">
            <li>
                <a href="#" onclick="event.preventDefault(); document.getElementById('listings-destroy-form-<?php echo e($listing->id); ?>').submit();">Remove</a>
            </li>
            <li><a href="<?php echo e(route('listings.edit', [$area, $listing])); ?>">Edit</a></li>
        </ul>
    </div>
</div>

<form action="<?php echo e(route('listings.destroy', [$area, $listing])); ?>" method="post" id="listings-destroy-form-<?php echo e($listing->id); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('DELETE')); ?>

</form>
