<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('listings.partials._search', [
        'category' => $category
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <h4><?php echo e($category->parent->name); ?> &nbsp; > &nbsp; <?php echo e($category->name); ?></h4>

    <hr>

    <?php if($listings->count()): ?>
        <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('listings.partials._listing', compact('listing'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($listings->links()); ?>

    <?php else: ?>
        <p>No listings found.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>