<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Create listing</div>
                <div class="panel-body">
                    <form action="<?php echo e(route('listings.store', [$area])); ?>" method="post">
                        <?php echo $__env->make('listings.partials.forms._areas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('listings.partials.forms._categories', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <label for="title" class="control-label">Title</label>
                            <input type="text" name="title" id="title" class="form-control">

                            <?php if($errors->has('title')): ?>
                                <span class="help-block">
                                    <?php echo e($errors->first('title')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('body') ? ' has-error' : ''); ?>">
                            <label for="body" class="control-label">Body</label>
                            <textarea name="body" id="body" cols="30" rows="8" class="form-control"></textarea>

                            <?php if($errors->has('body')): ?>
                                <span class="help-block">
                                    <?php echo e($errors->first('body')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-default">Save</button>
                        </div>

                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>