<div class="form-group<?php echo e($errors->has('area_id') ? ' has-error' : ''); ?>">
    <label for="area" class="control-label">Area</label>
    <select name="area_id" id="area" class="form-control">
        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <optgroup label="<?php echo e($country->name); ?>">
                <?php $__currentLoopData = $country->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <optgroup label="<?php echo e($state->name); ?>">
                        <?php $__currentLoopData = $state->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(
                                isset($listing) && $listing->area->id == $city->id ||
                                !isset($listing) && $area->id == $city->id && !old('area_id') ||
                                old('area_id') == $city->id
                            ): ?>
                                <option value="<?php echo e($city->id); ?>" selected="selected"><?php echo e($city->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </optgroup>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php if($errors->has('area_id')): ?>
        <span class="help-block">
            <?php echo e($errors->first('area_id')); ?>

        </span>
    <?php endif; ?>
</div>
