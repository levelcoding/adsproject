<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('layouts.partials._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body>
        <div id="app">
            <?php echo $__env->make('layouts.partials._navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="container">
                <?php echo $__env->make('layouts.partials._alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

        <!-- Scripts -->
        <script src="/js/app.js"></script>
    </body>
</html>
