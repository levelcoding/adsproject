<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-body">
            <div class="row">
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                        <h3><a href="<?php echo e(route('user.area.store', $country)); ?>"><?php echo e($country->name); ?></a></h3>
                        <hr>
                        
                        <div class="row">
                            <?php $__currentLoopData = $country->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <h4><a href="<?php echo e(route('user.area.store', $state)); ?>"><?php echo e($state->name); ?></a></h4>
                                    <hr>

                                    <?php $__currentLoopData = $state->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h5><a href="<?php echo e(route('user.area.store', $city)); ?>"><?php echo e($city->name); ?></a></h5>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>