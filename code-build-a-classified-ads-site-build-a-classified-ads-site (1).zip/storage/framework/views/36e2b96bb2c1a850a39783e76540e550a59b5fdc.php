<?php echo e($sender->name); ?> has shared a listing, <a href="<?php echo e(route('listings.show', [$listing->area, $listing])); ?>"><?php echo e($listing->title); ?></a>.<br><br>

<?php if($body): ?>
    ---<br>
    <?php echo nl2br(e($body)); ?><br>
    ---<br><br>
<?php endif; ?>