<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Share listing <em><?php echo e($listing->title); ?></em></div>
                <div class="panel-body">
                    <p>Share this listing with up to 5 people</p>

                    <form action="<?php echo e(route('listings.share.store', [$area, $listing])); ?>" method="post">
                        <?php $__currentLoopData = range(0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group<?php echo e($errors->has('emails.' . $n) ? ' has-error' : ''); ?>">
                                <label for="emails.<?php echo e($n); ?>" class="hidden">Email</label>
                                <input type="text" name="emails[]" id="emails.<?php echo e($n); ?>" class="form-control" placeholder="someone@somewhere.com" value="<?php echo e(old('emails.' . $n)); ?>">

                                <?php if($errors->has('emails.' . $n)): ?>
                                    <span class="help-block">
                                        <?php echo e($errors->first('emails.' . $n)); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
                            <label for="message">Message (optional)</label>
                            <textarea name="message" id="message" cols="30" rows="5" class="form-control"></textarea>

                            <?php if($errors->has('message')): ?>
                                <span class="help-block">
                                    <?php echo e($errors->first('message')); ?>

                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-default">Send</button>
                        </div>

                        <?php echo e(csrf_field()); ?>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>