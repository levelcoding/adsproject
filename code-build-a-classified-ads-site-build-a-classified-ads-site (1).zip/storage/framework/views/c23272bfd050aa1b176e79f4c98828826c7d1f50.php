<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('listings.partials._search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div class="row">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <h5><?php echo e($category->name); ?></h5>
                <hr>
                
                <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5><a href="<?php echo e(route('listings.index', [$area, $sub])); ?>"><?php echo e($sub->name); ?></a> (<?php echo e($sub->listings->count()); ?>)</h5>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>