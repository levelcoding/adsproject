<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(Auth::check()): ?>
            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <nav class="nav nav-stacked">
                            <li><a href="<?php echo e(route('listings.share.index', [$area, $listing])); ?>">Email to a friend</a></li>
                            <?php if(!$listing->favouritedBy(Auth::user())): ?>
                                <li>
                                    <a href="#" onclick="event.preventDefault(); document.getElementById('listings-favourite-form').submit();">Add to favourites</a>

                                    <form action="<?php echo e(route('listings.favourites.store', [$area, $listing])); ?>" method="post" id="listings-favourite-form" class="hidden">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            <?php endif; ?>
                        </nav>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="<?php echo e(Auth::check() ? 'col-md-9' : 'col-md-12'); ?>">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4><?php echo e($listing->title); ?> in <span class="text-muted"><?php echo e($listing->area->name); ?></span></h4>
                </div>
                <div class="panel-body">
                    <?php echo nl2br(e($listing->body)); ?>

                    <hr>
                    <p>Viewed <?php echo e($listing->views()); ?> times</p>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">
                    Contact <?php echo e($listing->user->name); ?>

                </div>
                <div class="panel-body">
                    <?php if(Auth::guest()): ?>
                        <p><a href="/register">Sign up</a> for an account or <a href="/login">sign in</a> to contact listing owners.</p>
                    <?php else: ?>
                        <form action="<?php echo e(route('listings.contact.store', [$area, $listing])); ?>" method="post">
                            <div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
                                <label for="message" class="control-label">Message</label>
                                <textarea name="message" id="message" cols="30" rows="5" class="form-control"></textarea>

                                <?php if($errors->has('message')): ?>
                                    <span class="help-block">
                                        <?php echo e($errors->first('message')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-default">Send</button>
                                <span class="help-block">
                                    This will email <?php echo e($listing->user->name); ?> and they'll be able to reply directly to you by email.
                                </span>
                            </div>

                            <?php echo e(csrf_field()); ?>

                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>