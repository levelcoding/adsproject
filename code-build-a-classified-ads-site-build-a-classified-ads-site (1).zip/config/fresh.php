<?php

return [
    'defaults' => [
        'area' => 'us'
    ]
];
